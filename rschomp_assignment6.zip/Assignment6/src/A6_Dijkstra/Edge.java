package A6_Dijkstra;

public class Edge {
	String elabel;
	long idNum;
	long weight;
	Vertex thisVertex;
	Edge nextEdge;
	String dlabel;
	
	public Edge(long idNum, long weight, String elabel, String dlabel){ 
		this.idNum = idNum;
		this.weight = weight;
		this.elabel = elabel;
		this.thisVertex = null;
		this.nextEdge = null;
		this.dlabel = dlabel;
	}

	public Long getWeight() {
		return weight;
	}

	public Object getDLabel() {
		return dlabel;
	}
	
}
