package A6_Dijkstra;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Stack;
import java.util.ArrayList;
public class DiGraph implements DiGraph_Interface {

  // in here go all your data and methods for the graph
  // and the topo sort operation
  private List<String>edgeStrings;
  HashMap<String, Vertex> hm;
  HashSet<Long>edgeInfo, vertexInfo;
  public long countVertex;
  public long countEdges;
  public Vertex vertexArray[];
  private Map<String,LinkedList<Edge>> vertices = new HashMap<String,LinkedList<Edge>>();
  Queue<Vertex> vertexOrder;
  HashMap<String, Long> mapOfDistance;
  ArrayList<ShortestPathInfo> havePaths;
  //private HashMap<String, List<String>> hm2;
  //private ArrayList<List<Node>> adList;
	
  public DiGraph ( ) { // default constructor
	  this.edgeStrings = new ArrayList<String>();
	  this.hm = new HashMap<String, Vertex>();
	  this.edgeInfo = new HashSet<Long>();
	  this.vertexInfo = new HashSet<Long>();
	  this.vertexOrder = new LinkedList<Vertex>();
	  this.mapOfDistance = new HashMap<String, Long>();
	  this.havePaths = new ArrayList<ShortestPathInfo>();
	  countVertex = 0;
	  countEdges = 0;
	  vertexArray = new Vertex[1000];
	  
	 // hm = new HashMap<Long, String>();
	 // hm2 = new HashMap<String, List<String>>();
	  // explicitly include this
    // we need to have the default constructor
    // if you then write others, this one will still be there
  }
  
@Override
public boolean addNode(long idNum, String label) {
	
	if (idNum < 0 ){
		return false;
	}
	if(label == null){
		return false;
	}
	if(vertexInfo.contains(idNum)){
		return false;
	}
	if(hm.containsKey(label)){
		return false;
	}
		Vertex vertex = new Vertex(idNum, label); //creating a new node
		vertexInfo.add(idNum); //add info about node to hashset
		vertexArray[(int) idNum] = vertex; //put that vertex in array for queing in topo
		hm.put(label, vertex); //put vertex in hashmap
		vertices.put(label, new LinkedList<Edge>());
		countVertex++; //upcount
		return true;

}

@Override
public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {
	String conForAdd = sLabel+dLabel;
	
	if(edgeInfo.contains(idNum) == true){
		return false;
	}
	else if(idNum < 0){
		return false;
	}
	else if(hm.containsKey(sLabel) == false){
		return false;
	}
	else if(hm.containsKey(dLabel) == false){
		return false;
	}
	else if(edgeStrings.contains(conForAdd)){
		return false;
	}
	
	else {
	Edge edge = new Edge (idNum, weight, eLabel, dLabel); 
	edge.nextEdge = hm.get(sLabel).theEdge;
	hm.get(sLabel).theEdge = edge;
	edge.thisVertex = hm.get(dLabel);
	
	edgeStrings.add(conForAdd);
	vertices.get(sLabel).add(edge);
	
	hm.get(dLabel).inArrows++;//you have another arrow coming in
	hm.get(sLabel).outArrows++;//you have another arrow going out
	edgeInfo.add(idNum);
	countEdges++;

	return true;
	}
}
	

/*
	if(edgeStrings.contains(conOne)){
		//edge already made
		return false;
	}
	else if (numNodes < 2){
		return false;
	}
	else if (idNum < 0){
		return false;
	}
	else if (!vertices.containsKey(sLabel) || !vertices.containsKey(dLabel)){
		return false;
	}
	else if(edge_ids.contains(idNum)){
		return false;
	}
	else{
		Vertex fromVertex = vertices.get(sLabel);
		Vertex toVertex = vertices.get(dLabel);
		Edge newEdge = new Edge(idNum, fromVertex, toVertex, weight, eLabel);
		edgeStrings.add(conOne);
		edgeStrings.add(conTwo);
		
	}
	return false;
}
*/
@Override
public boolean delNode(String label) {
	if(hm.containsKey(label) == false){
		return false;
	}
	for (int i = 0; i <= vertexArray.length-1; i++){
		if(vertexArray[i] != null){
			this.delEdge(vertexArray[i].label, label);
		}
	}
	
	Vertex vertex = hm.get(label);//get it first
	hm.remove(label);//now you can remove it
	vertexArray[(int) vertex.idNum] = null;
	vertexInfo.remove(vertex.idNum);
	vertices.remove(label);
	countVertex--;
	
	return true;
}
	

@Override
public boolean delEdge(String sLabel, String dLabel) {
	String conForDel = sLabel+dLabel;
	
	if(hm.containsKey(sLabel) == false){
		return false;
	}
	else if(hm.containsKey(dLabel) == false){
		return false;
	}	
	else if(hm.get(sLabel) == null){
		return false;
	}
	else if(hm.get(dLabel) == null){
		return false;
	}
	
	else if(!edgeStrings.contains(conForDel)){
		return false;
	}
	else {
	Edge priorEdge = null;
	Edge tempEdge = hm.get(sLabel).theEdge;
	
	edgeStrings.remove(conForDel);
	
	
	while(tempEdge != null){
		if(hm.get(dLabel) != tempEdge.thisVertex){
			priorEdge = tempEdge;
			tempEdge = tempEdge.nextEdge;
		}
		else{
			if(priorEdge != null){
				priorEdge.nextEdge = tempEdge.nextEdge;
			}
			else{
				hm.get(sLabel).theEdge = tempEdge.nextEdge;
			}
			edgeInfo.remove(tempEdge.idNum);
			vertices.remove(tempEdge.idNum);
			hm.get(dLabel).inArrows--;
			hm.get(sLabel).outArrows--;
			countEdges--;
			return true;
		}
		
	}
	return false;
	}
}


@Override
public long numNodes() {
	// TODO Auto-generated method stub
	return countVertex;
}

@Override
public long numEdges() {
	// TODO Auto-generated method stub
	return countEdges;
}
int i = 0;
@Override
public String[] topoSort() {
	int counter = 0;
	Edge newerEdge;
	String fn, tn;
	int integer = 0;
	String[] topoArray = new String[10000];
	Stack<String> queue = new Stack<String>();
	Stack<String> extraQueue = new Stack<String>();
	
	for(i = 0; i <= vertexArray.length-1; i++){
		if(vertexArray[i] == null || vertexArray[i].inArrows != 0){	//nothing in array or has in arrows, dont start here
		}
		else{
			queue.push(vertexArray[i].label);//push onto stack
		}
	}
	
	while(queue.size() != 0){
		fn = queue.pop();
		topoArray[counter] = fn;
		newerEdge = this.vertexArray[(int) hm.get(fn).idNum].theEdge;
		counter++;
		
		while(newerEdge != null){
			extraQueue.push(newerEdge.thisVertex.label);
			newerEdge = newerEdge.nextEdge;
		}
		
		while(extraQueue.size() > 0){
			tn = extraQueue.pop();
			this.delEdge(fn, tn);
			if(this.hm.get(tn).inArrows == 0){
				queue.push(tn);
			}
		}
	}
	
	for(i = 0; i <= topoArray.length-1; i++){
		if(topoArray[i] != null){
			integer++;
		}
	}
	
	if(integer != this.countVertex){
		return null;
	}
	else {
		String[] copy = new String[integer];
		for(i = 0; i <= integer-1; i++){
			copy[i] = topoArray[i];
		}
		return copy;
	}
}

@Override
public ShortestPathInfo[] shortestPath(String label) {

	for(Entry<String, Vertex> entry: hm.entrySet()){ //put all nodes and initial values in distance map
		if(!entry.getKey().equals(label)){
			mapOfDistance.put(entry.getKey(), Long.MAX_VALUE);
		} 
		else {
			mapOfDistance.put(entry.getKey(), (long) 0);
			vertexOrder.add(hm.get(label));
		}
	}
			
	while(!vertexOrder.isEmpty()){ //going through q and comparing edges
		Vertex currentVertex = vertexOrder.remove();
	
		for(Edge edge: vertices.get(currentVertex.getLabel())){
			Vertex destVertex = hm.get(edge.getDLabel()); //get dest label of edge, get end vertex
			long distance = mapOfDistance.get(currentVertex.getLabel()) + edge.getWeight();

			if(distance <= mapOfDistance.get(destVertex.getLabel())-1 //if distance has changed
					|| mapOfDistance.get(destVertex.getLabel()) == Long.MAX_VALUE){
				vertexOrder.add(new Vertex(destVertex.getId(), destVertex.getLabel()));
				mapOfDistance.put(destVertex.getLabel(), distance);
			}
		}
	}
		
	for(Entry<String, Long> set: mapOfDistance.entrySet()){ //one time lookup set
		if(set.getValue() != Long.MAX_VALUE){
			havePaths.add(new ShortestPathInfo(set.getKey(), set.getValue())); //add new shortest path
		} else {
			havePaths.add(new ShortestPathInfo(set.getKey(), -1)); //if path from s2d does not exist, set totalWeight to -1
		}
	}
	ShortestPathInfo shortestPaths[] = new ShortestPathInfo[(int) countVertex]; //convert to array
	havePaths.toArray(shortestPaths);
	return shortestPaths;
}
}


